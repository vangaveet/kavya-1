const hello = () => {
    console.log("Hello Node.js!");
  };
  
  hello();